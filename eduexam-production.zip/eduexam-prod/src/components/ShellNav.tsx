"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";

export function ShellNav({
  roleTitle,
  userName,
  items,
}: {
  roleTitle: string;
  userName: string;
  items: Array<{ href: string; label: string }>;
}) {
  const pathname = usePathname();
  const router = useRouter();

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  }

  return (
    <aside className="w-60 shrink-0 bg-white border-r border-slate-200 flex flex-col justify-between p-4 min-h-screen">
      <div>
        <div className="flex items-center gap-2.5 pb-4 mb-4 border-b border-slate-200">
          <div className="w-8 h-8 rounded-lg bg-blue-700 text-white font-bold flex items-center justify-center">E</div>
          <div>
            <div className="font-bold text-sm text-slate-900">EduExam</div>
            <div className="text-xs text-slate-500">{roleTitle}</div>
          </div>
        </div>
        <nav className="space-y-1">
          {items.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`block px-3 py-2 rounded-lg text-sm font-medium ${active ? "bg-blue-50 text-blue-700" : "text-slate-600 hover:bg-slate-100"}`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>
      <div className="pt-4 border-t border-slate-200 space-y-2">
        <div className="text-xs font-medium text-slate-800 px-2">{userName}</div>
        <button onClick={logout} className="w-full text-left px-2 py-1.5 text-xs text-slate-600 hover:text-rose-700 rounded">
          退出登录
        </button>
      </div>
    </aside>
  );
}
