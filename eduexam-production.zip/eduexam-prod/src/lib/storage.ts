import fs from "fs/promises";
import path from "path";

export interface StorageProvider {
  saveFile(filename: string, buffer: Buffer): Promise<string>;
}

class LocalStorageProvider implements StorageProvider {
  private dir: string;
  constructor() {
    this.dir = process.env.LOCAL_UPLOAD_DIR || "./uploads";
  }
  async saveFile(filename: string, buffer: Buffer): Promise<string> {
    await fs.mkdir(this.dir, { recursive: true });
    const safeName = `${Date.now()}_${filename.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
    const fullPath = path.join(this.dir, safeName);
    await fs.writeFile(fullPath, buffer);
    return `/uploads/${safeName}`;
  }
}

export function getStorageProvider(): StorageProvider {
  return new LocalStorageProvider();
}
