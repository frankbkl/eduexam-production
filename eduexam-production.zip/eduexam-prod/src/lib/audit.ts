import { prisma } from "./prisma";

export async function logAudit(params: {
  userId?: string | null;
  actorName: string;
  action: string;
  target?: string;
  detail: string;
}) {
  try {
    await prisma.auditLog.create({
      data: {
        userId: params.userId ?? null,
        actorName: params.actorName,
        action: params.action,
        target: params.target ?? null,
        detail: params.detail,
      },
    });
  } catch (e) {
    console.error("Audit log failed:", e);
  }
}
