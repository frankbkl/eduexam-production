import { prisma } from "./prisma";
import { logAudit } from "./audit";

export async function finalizeAttempt(attemptId: string, isAutoSubmit: boolean) {
  return prisma.$transaction(async (tx) => {
    const attempt = await tx.examAttempt.findUnique({
      where: { id: attemptId },
      include: {
        exam: true,
        student: true,
        answers: true,
      },
    });

    if (!attempt || attempt.status !== "IN_PROGRESS") {
      return attempt;
    }

    const questions = await tx.examQuestion.findMany({
      where: attempt.exam.mode === "RANDOM"
        ? { examId: attempt.examId, attemptId: attempt.id }
        : { examId: attempt.examId, attemptId: null },
      orderBy: { orderIndex: "asc" },
    });

    const answerMap = new Map(attempt.answers.map((a) => [a.examQuestionId, a.answerPayload]));
    let objectiveTotal = 0;
    let hasSubjective = false;

    for (const q of questions) {
      const payload = answerMap.get(q.id) as unknown;
      let score: number | null = 0;
      let isAutoGraded = true;

      if (q.type === "SINGLE") {
        const corr = (q.correctAnswer as string[]) || [];
        const userAns = Array.isArray(payload) ? payload : [];
        score = userAns.length === 1 && userAns[0] === corr[0] ? q.score : 0;
        objectiveTotal += score;
      } else if (q.type === "MULTIPLE") {
        const corr = [...((q.correctAnswer as string[]) || [])].sort();
        const userAns = Array.isArray(payload) ? [...(payload as string[])].sort() : [];
        if (userAns.length === corr.length && userAns.every((v, i) => v === corr[i])) {
          score = q.score;
        } else if (q.partialRule === "ALL_OR_HALF" && userAns.length > 0 && userAns.every((v) => corr.includes(v))) {
          score = Math.round((q.score / 2) * 10) / 10;
        } else {
          score = 0;
        }
        objectiveTotal += score;
      } else if (q.type === "BLANK") {
        const blanks = (q.blanksSnapshot as Array<{ acceptableAnswers: string[]; score: number; ignoreCase: boolean; trimSpace: boolean }>) || [];
        const userBlanks = Array.isArray(payload) ? (payload as string[]) : [];
        let pts = 0;
        blanks.forEach((b, idx) => {
          let val = String(userBlanks[idx] ?? "");
          if (b.trimSpace) val = val.trim();
          const ok = b.acceptableAnswers.some((acc) => {
            const target = b.trimSpace ? acc.trim() : acc;
            return b.ignoreCase ? val.toLowerCase() === target.toLowerCase() : val === target;
          });
          if (ok) pts += Number(b.score || 0);
        });
        score = Math.round(pts * 10) / 10;
        objectiveTotal += score;
      } else if (q.type === "SUBJECTIVE") {
        hasSubjective = true;
        score = null;
        isAutoGraded = false;
      }

      await tx.questionScore.upsert({
        where: { attemptId_examQuestionId: { attemptId: attempt.id, examQuestionId: q.id } },
        create: {
          attemptId: attempt.id,
          examQuestionId: q.id,
          score,
          maxScore: q.score,
          isAutoGraded,
        },
        update: {
          score,
          maxScore: q.score,
          isAutoGraded,
        },
      });
    }

    const updated = await tx.examAttempt.update({
      where: { id: attempt.id },
      data: {
        status: hasSubjective ? "PENDING_GRADING" : "GRADED",
        submittedAt: new Date(),
        isAutoSubmitted: isAutoSubmit,
        objectiveScore: Math.round(objectiveTotal * 10) / 10,
        totalScore: hasSubjective ? null : Math.round(objectiveTotal * 10) / 10,
        teacherConfirmed: false,
      },
    });

    await logAudit({
      userId: attempt.studentId,
      actorName: attempt.student.name,
      action: isAutoSubmit ? "AUTO_SUBMIT_EXAM" : "SUBMIT_EXAM",
      target: attempt.examId,
      detail: `${isAutoSubmit ? "到期自动交卷" : "主动交卷"}《${attempt.exam.title}》，客观题得分 ${objectiveTotal}`,
    });

    return updated;
  });
}

export async function sweepExpiredAttempts() {
  const expired = await prisma.examAttempt.findMany({
    where: {
      status: "IN_PROGRESS",
      expiresAt: { lte: new Date() },
    },
    select: { id: true },
  });
  for (const item of expired) {
    await finalizeAttempt(item.id, true);
  }
  return expired.length;
}
