import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { sweepExpiredAttempts } from "@/lib/grading";

export async function GET() {
  try {
    const session = await requireRole(["STUDENT"]);
    await sweepExpiredAttempts();

    const profile = await prisma.studentProfile.findUnique({
      where: { userId: session.userId },
      include: { classes: true },
    });
    const classIds = (profile?.classes || []).map((c) => c.classId);

    const exams = await prisma.exam.findMany({
      where: {
        status: "PUBLISHED",
        assignments: { some: { OR: [{ classId: { in: classIds } }, { studentId: session.userId }] } },
      },
      include: {
        attempts: { where: { studentId: session.userId }, orderBy: { attemptNo: "desc" } },
      },
      orderBy: { startTime: "desc" },
    });

    const sanitized = exams.map((e) => ({
      ...e,
      attempts: e.attempts.map((a) => ({
        id: a.id,
        status: a.status,
        startedAt: a.startedAt,
        expiresAt: a.expiresAt,
        submittedAt: a.submittedAt,
        teacherConfirmed: a.teacherConfirmed,
        totalScore: a.teacherConfirmed && e.releasePolicy === "IMMEDIATE" ? a.totalScore : null,
      })),
    }));

    return NextResponse.json({ exams: sanitized });
  } catch {
    return NextResponse.json({ error: "查询失败" }, { status: 500 });
  }
}
