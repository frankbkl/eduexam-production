import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { logAudit } from "@/lib/audit";

export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await requireRole(["STUDENT"]);
    const { id } = await params;
    const exam = await prisma.exam.findUnique({ where: { id } });
    if (!exam || exam.status !== "PUBLISHED") return NextResponse.json({ error: "考试不存在或未发布" }, { status: 404 });

    const now = Date.now();
    if (now < exam.startTime.getTime() || now > exam.endTime.getTime()) {
      return NextResponse.json({ error: "不在考试开放时间窗口内" }, { status: 400 });
    }

    const existing = await prisma.examAttempt.findMany({
      where: { examId: id, studentId: session.userId },
      orderBy: { attemptNo: "desc" },
    });

    const inProg = existing.find((a) => a.status === "IN_PROGRESS");
    if (inProg) return NextResponse.json({ attempt: inProg });

    if (!exam.allowRetake && existing.length > 0) {
      return NextResponse.json({ error: "本场考试不允许重复参加" }, { status: 400 });
    }

    const expiresAt = new Date(Math.min(now + exam.durationMinutes * 60000, exam.endTime.getTime()));
    const attempt = await prisma.$transaction(async (tx) => {
      const att = await tx.examAttempt.create({
        data: {
          examId: id,
          studentId: session.userId,
          attemptNo: existing.length + 1,
          expiresAt,
        },
      });

      if (exam.mode === "RANDOM" && exam.bankId) {
        const cfg = (exam.randomConfig as { count?: number; scorePerQuestion?: number }) || {};
        const pool = await tx.question.findMany({
          where: { bankId: exam.bankId },
          include: { options: true, blanks: true },
        });
        const picked = pool.sort(() => Math.random() - 0.5).slice(0, cfg.count || 3);
        const perScore = cfg.scorePerQuestion || 10;
        for (let i = 0; i < picked.length; i++) {
          const q = picked[i];
          await tx.examQuestion.create({
            data: {
              examId: id,
              attemptId: att.id,
              originQuestionId: q.id,
              orderIndex: i,
              type: q.type,
              content: q.content,
              score: perScore,
              optionsSnapshot: q.options.map((o) => ({ key: o.key, text: o.text })),
              correctAnswer: q.options.filter((o) => o.isCorrect).map((o) => o.key),
              blanksSnapshot: q.blanks.map((b) => ({
                acceptableAnswers: b.acceptableAnswers,
                score: b.score,
                ignoreCase: b.ignoreCase,
                trimSpace: b.trimSpace,
              })),
              referenceAnswer: q.referenceAnswer,
              rubric: q.rubric,
              explanation: q.explanation,
              partialRule: q.partialRule,
              needsManualGrading: q.needsManualGrading,
            },
          });
        }
      }
      return att;
    });

    await logAudit({ userId: session.userId, actorName: session.name, action: "START_EXAM", target: id, detail: `开始考试《${exam.title}》` });
    return NextResponse.json({ attempt });
  } catch (e) {
    return NextResponse.json({ error: "开考失败", detail: String(e) }, { status: 500 });
  }
}
