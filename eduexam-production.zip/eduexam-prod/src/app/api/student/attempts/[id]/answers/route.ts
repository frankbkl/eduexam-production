import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { finalizeAttempt } from "@/lib/grading";

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await requireRole(["STUDENT"]);
    const { id } = await params;
    const { answers } = await req.json() as { answers: Array<{ examQuestionId: string; answerPayload: unknown }> };

    const attempt = await prisma.examAttempt.findUnique({ where: { id } });
    if (!attempt || attempt.studentId !== session.userId) return NextResponse.json({ error: "无权操作" }, { status: 403 });
    if (attempt.status !== "IN_PROGRESS") return NextResponse.json({ error: "试卷已提交，禁止修改" }, { status: 400 });
    if (attempt.expiresAt.getTime() <= Date.now()) {
      await finalizeAttempt(id, true);
      return NextResponse.json({ error: "考试已到期，系统已自动交卷" }, { status: 400 });
    }

    await prisma.$transaction(
      (answers || []).map((a) =>
        prisma.studentAnswer.upsert({
          where: { attemptId_examQuestionId: { attemptId: id, examQuestionId: a.examQuestionId } },
          create: { attemptId: id, examQuestionId: a.examQuestionId, answerPayload: a.answerPayload as never },
          update: { answerPayload: a.answerPayload as never },
        })
      )
    );

    return NextResponse.json({ savedAt: new Date().toISOString() });
  } catch (e) {
    return NextResponse.json({ error: "保存失败", detail: String(e) }, { status: 500 });
  }
}
