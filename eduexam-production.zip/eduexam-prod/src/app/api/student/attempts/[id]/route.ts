import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { finalizeAttempt } from "@/lib/grading";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await requireRole(["STUDENT"]);
    const { id } = await params;
    let attempt = await prisma.examAttempt.findUnique({
      where: { id },
      include: { exam: true, answers: true, scores: true },
    });
    if (!attempt || attempt.studentId !== session.userId) {
      return NextResponse.json({ error: "无权访问该答卷" }, { status: 403 });
    }

    if (attempt.status === "IN_PROGRESS" && attempt.expiresAt.getTime() <= Date.now()) {
      await finalizeAttempt(attempt.id, true);
      attempt = await prisma.examAttempt.findUnique({
        where: { id },
        include: { exam: true, answers: true, scores: true },
      });
    }
    if (!attempt) return NextResponse.json({ error: "Not found" }, { status: 404 });

    const questions = await prisma.examQuestion.findMany({
      where: attempt.exam.mode === "RANDOM" ? { examId: attempt.examId, attemptId: attempt.id } : { examId: attempt.examId, attemptId: null },
      orderBy: { orderIndex: "asc" },
    });

    const canReveal = attempt.teacherConfirmed === true && attempt.status === "GRADED" && attempt.exam.showAnswers && attempt.exam.releasePolicy === "IMMEDIATE";

    const safeQuestions = questions.map((q) => ({
      id: q.id,
      orderIndex: q.orderIndex,
      type: q.type,
      content: q.content,
      score: q.score,
      optionsSnapshot: q.optionsSnapshot,
      blankCount: Array.isArray(q.blanksSnapshot) ? q.blanksSnapshot.length : 0,
      ...(canReveal ? {
        correctAnswer: q.correctAnswer,
        referenceAnswer: q.referenceAnswer,
        explanation: q.explanation,
      } : {}),
    }));

    return NextResponse.json({
      attempt: {
        id: attempt.id,
        status: attempt.status,
        startedAt: attempt.startedAt,
        expiresAt: attempt.expiresAt,
        submittedAt: attempt.submittedAt,
        teacherConfirmed: attempt.teacherConfirmed,
        objectiveScore: canReveal ? attempt.objectiveScore : null,
        totalScore: canReveal ? attempt.totalScore : null,
        examTitle: attempt.exam.title,
        examTotalScore: attempt.exam.totalScore,
        showAnswers: attempt.exam.showAnswers,
        answers: attempt.answers,
        scores: canReveal ? attempt.scores : [],
      },
      questions: safeQuestions,
    });
  } catch {
    return NextResponse.json({ error: "读取失败" }, { status: 500 });
  }
}
