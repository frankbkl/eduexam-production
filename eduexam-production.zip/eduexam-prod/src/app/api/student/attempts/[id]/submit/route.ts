import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { finalizeAttempt } from "@/lib/grading";

export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await requireRole(["STUDENT"]);
    const { id } = await params;
    const attempt = await prisma.examAttempt.findUnique({ where: { id } });
    if (!attempt || attempt.studentId !== session.userId) return NextResponse.json({ error: "无权交卷" }, { status: 403 });

    const finalized = await finalizeAttempt(id, false);
    return NextResponse.json({ attempt: finalized });
  } catch (e) {
    return NextResponse.json({ error: "交卷失败", detail: String(e) }, { status: 500 });
  }
}
