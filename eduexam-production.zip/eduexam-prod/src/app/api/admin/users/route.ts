import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole, hashPassword } from "@/lib/auth";
import { logAudit } from "@/lib/audit";

export async function GET() {
  try {
    await requireRole(["ADMIN"]);
    const users = await prisma.user.findMany({
      select: { id: true, name: true, email: true, role: true, status: true, createdAt: true, studentProfile: true, teacherProfile: true },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ users });
  } catch {
    return NextResponse.json({ error: "无权访问" }, { status: 403 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await requireRole(["ADMIN"]);
    const { name, email, role, meta } = await req.json();
    const passwordHash = await hashPassword("123456");
    const user = await prisma.user.create({
      data: {
        name: String(name).trim(),
        email: String(email).trim().toLowerCase(),
        passwordHash,
        role,
        studentProfile: role === "STUDENT" ? { create: { studentNo: meta || `S${Date.now()}` } } : undefined,
        teacherProfile: role === "TEACHER" ? { create: { title: meta || "讲师" } } : undefined,
      },
    });
    await logAudit({ userId: session.userId, actorName: session.name, action: "CREATE_USER", target: user.id, detail: `管理员创建 ${role} 账号 ${user.name}` });
    return NextResponse.json({ user });
  } catch (e) {
    return NextResponse.json({ error: "创建账号失败", detail: String(e) }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const session = await requireRole(["ADMIN"]);
    const { id, status } = await req.json();
    const user = await prisma.user.update({ where: { id }, data: { status } });
    await logAudit({ userId: session.userId, actorName: session.name, action: "TOGGLE_USER", target: id, detail: `变更用户 ${user.name} 状态为 ${status}` });
    return NextResponse.json({ user });
  } catch {
    return NextResponse.json({ error: "更新失败" }, { status: 500 });
  }
}
