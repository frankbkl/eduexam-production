import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    await requireRole(["ADMIN"]);
    const { id } = await params;
    const { teacherProfileIds, studentProfileIds } = await req.json() as { teacherProfileIds: string[]; studentProfileIds: string[] };

    await prisma.$transaction(async (tx) => {
      await tx.teacherClass.deleteMany({ where: { classId: id } });
      await tx.classStudent.deleteMany({ where: { classId: id } });
      if (teacherProfileIds?.length) {
        await tx.teacherClass.createMany({ data: teacherProfileIds.map((tid) => ({ classId: id, teacherId: tid })) });
      }
      if (studentProfileIds?.length) {
        await tx.classStudent.createMany({ data: studentProfileIds.map((sid) => ({ classId: id, studentId: sid })) });
      }
    });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "分配失败" }, { status: 500 });
  }
}
