import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";

export async function GET() {
  try {
    await requireRole(["ADMIN", "TEACHER"]);
    const classes = await prisma.class.findMany({
      include: {
        teachers: { include: { teacher: { include: { user: { select: { id: true, name: true } } } } } },
        students: { include: { student: { include: { user: { select: { id: true, name: true } } } } } },
      },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ classes });
  } catch {
    return NextResponse.json({ error: "查询失败" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await requireRole(["ADMIN"]);
    const { name, grade } = await req.json();
    const cls = await prisma.class.create({ data: { name: String(name).trim(), grade: String(grade || "2026级").trim() } });
    return NextResponse.json({ class: cls });
  } catch {
    return NextResponse.json({ error: "创建班级失败" }, { status: 500 });
  }
}
