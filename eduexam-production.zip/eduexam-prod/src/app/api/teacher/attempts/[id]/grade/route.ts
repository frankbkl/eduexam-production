import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { logAudit } from "@/lib/audit";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await requireRole(["TEACHER"]);
    const { id } = await params;
    const { grades } = await req.json() as { grades: Array<{ examQuestionId: string; score: number; comment?: string }> };

    const attempt = await prisma.examAttempt.findUnique({ where: { id }, include: { exam: true } });
    if (!attempt || attempt.exam.teacherId !== session.userId) {
      return NextResponse.json({ error: "无权评分" }, { status: 403 });
    }

    const updated = await prisma.$transaction(async (tx) => {
      for (const g of grades || []) {
        const q = await tx.examQuestion.findUnique({ where: { id: g.examQuestionId } });
        if (!q) continue;
        const clamped = Math.max(0, Math.min(q.score, Number(g.score)));
        await tx.questionScore.upsert({
          where: { attemptId_examQuestionId: { attemptId: id, examQuestionId: g.examQuestionId } },
          create: { attemptId: id, examQuestionId: g.examQuestionId, score: clamped, maxScore: q.score, isAutoGraded: false, comment: g.comment || "", gradedBy: session.userId },
          update: { score: clamped, comment: g.comment || "", gradedBy: session.userId },
        });
      }

      const allScores = await tx.questionScore.findMany({ where: { attemptId: id } });
      const allGraded = allScores.length > 0 && allScores.every((s) => s.score !== null);
      const total = allScores.reduce((sum, s) => sum + (s.score || 0), 0);

      return tx.examAttempt.update({
        where: { id },
        data: {
          status: allGraded ? "GRADED" : "PENDING_GRADING",
          totalScore: allGraded ? Math.round(total * 10) / 10 : null,
          teacherConfirmed: allGraded,
        },
      });
    });

    await logAudit({ userId: session.userId, actorName: session.name, action: "GRADE_ATTEMPT", target: id, detail: `完成答卷 ${id} 评分确认，状态：${updated.status}` });
    return NextResponse.json({ attempt: updated });
  } catch (e) {
    return NextResponse.json({ error: "评分保存失败", detail: String(e) }, { status: 500 });
  }
}
