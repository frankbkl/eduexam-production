import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await requireRole(["TEACHER"]);
    const { id } = await params;
    const attempt = await prisma.examAttempt.findUnique({
      where: { id },
      include: { exam: true, student: { select: { name: true, email: true } }, answers: true, scores: true },
    });
    if (!attempt || attempt.exam.teacherId !== session.userId) {
      return NextResponse.json({ error: "无权查看" }, { status: 403 });
    }
    const questions = await prisma.examQuestion.findMany({
      where: attempt.exam.mode === "RANDOM" ? { examId: attempt.examId, attemptId: attempt.id } : { examId: attempt.examId, attemptId: null },
      orderBy: { orderIndex: "asc" },
    });
    return NextResponse.json({ attempt, questions });
  } catch {
    return NextResponse.json({ error: "查询失败" }, { status: 500 });
  }
}
