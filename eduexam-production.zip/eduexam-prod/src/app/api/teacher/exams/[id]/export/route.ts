import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import * as XLSX from "xlsx";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await requireRole(["TEACHER"]);
    const { id } = await params;
    const exam = await prisma.exam.findUnique({ where: { id } });
    if (!exam || exam.teacherId !== session.userId) return NextResponse.json({ error: "无权导出" }, { status: 403 });

    const attempts = await prisma.examAttempt.findMany({
      where: { examId: id },
      include: { student: { include: { studentProfile: true } } },
    });

    const rows = [
      ["学生姓名", "学号", "状态", "交卷时间", "客观题得分", "最终总分", "教师已确认"],
      ...attempts.map((a) => [
        a.student.name,
        a.student.studentProfile?.studentNo || "-",
        a.status,
        a.submittedAt ? a.submittedAt.toISOString() : "-",
        a.objectiveScore ?? "-",
        a.totalScore ?? "待阅卷",
        a.teacherConfirmed ? "是" : "否",
      ]),
    ];

    const ws = XLSX.utils.aoa_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "成绩单");
    const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });

    return new NextResponse(buf, {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename=exam_${id}_grades.xlsx`,
      },
    });
  } catch {
    return NextResponse.json({ error: "导出失败" }, { status: 500 });
  }
}
