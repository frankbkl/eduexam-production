import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { logAudit } from "@/lib/audit";

export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await requireRole(["TEACHER"]);
    const { id } = await params;
    const exam = await prisma.exam.findUnique({ where: { id } });
    if (!exam || exam.teacherId !== session.userId) return NextResponse.json({ error: "无权发布" }, { status: 403 });

    const updated = await prisma.exam.update({ where: { id }, data: { status: "PUBLISHED" } });
    await logAudit({ userId: session.userId, actorName: session.name, action: "PUBLISH_EXAM", target: id, detail: `发布考试《${exam.title}》` });
    return NextResponse.json({ exam: updated });
  } catch {
    return NextResponse.json({ error: "发布失败" }, { status: 500 });
  }
}
