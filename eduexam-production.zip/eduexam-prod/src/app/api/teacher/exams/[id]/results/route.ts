import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { sweepExpiredAttempts } from "@/lib/grading";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await requireRole(["TEACHER"]);
    const { id } = await params;
    await sweepExpiredAttempts();

    const exam = await prisma.exam.findUnique({ where: { id } });
    if (!exam || exam.teacherId !== session.userId) return NextResponse.json({ error: "无权查看" }, { status: 403 });

    const attempts = await prisma.examAttempt.findMany({
      where: { examId: id },
      include: { student: { select: { id: true, name: true, email: true, studentProfile: { select: { studentNo: true } } } } },
      orderBy: { submittedAt: "desc" },
    });

    const gradedScores = attempts.filter((a) => a.status === "GRADED" && a.totalScore !== null).map((a) => a.totalScore as number);
    const passLine = exam.totalScore * 0.6;
    const stats = {
      submittedCount: attempts.filter((a) => a.status !== "IN_PROGRESS").length,
      average: gradedScores.length ? Number((gradedScores.reduce((s, v) => s + v, 0) / gradedScores.length).toFixed(1)) : null,
      max: gradedScores.length ? Math.max(...gradedScores) : null,
      min: gradedScores.length ? Math.min(...gradedScores) : null,
      passRate: gradedScores.length ? Math.round((gradedScores.filter((s) => s >= passLine).length / gradedScores.length) * 100) : null,
    };

    return NextResponse.json({ exam, attempts, stats });
  } catch {
    return NextResponse.json({ error: "查询失败" }, { status: 500 });
  }
}
