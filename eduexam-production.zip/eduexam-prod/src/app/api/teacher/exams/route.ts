import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { logAudit } from "@/lib/audit";

export async function GET() {
  try {
    const session = await requireRole(["TEACHER"]);
    const exams = await prisma.exam.findMany({
      where: { teacherId: session.userId },
      include: { _count: { select: { attempts: true, questions: true } } },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ exams });
  } catch {
    return NextResponse.json({ error: "查询失败" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await requireRole(["TEACHER"]);
    const body = await req.json();
    const {
      title, description, bankId, mode, startTime, endTime, durationMinutes,
      allowEarlySubmit, allowRetake, releasePolicy, showAnswers, classIds, questionIds, randomConfig,
    } = body;

    if (!title) return NextResponse.json({ error: "考试名称不能为空" }, { status: 400 });

    const exam = await prisma.$transaction(async (tx) => {
      let totalScore = 0;
      const snapshotCreates: Array<Record<string, unknown>> = [];

      if (mode === "MANUAL" && Array.isArray(questionIds) && questionIds.length > 0) {
        const qs = await tx.question.findMany({
          where: { id: { in: questionIds } },
          include: { options: true, blanks: true },
        });
        qs.forEach((q, idx) => {
          totalScore += q.score;
          snapshotCreates.push({
            originQuestionId: q.id,
            orderIndex: idx,
            type: q.type,
            content: q.content,
            score: q.score,
            optionsSnapshot: q.options.map((o) => ({ key: o.key, text: o.text })),
            correctAnswer: q.options.filter((o) => o.isCorrect).map((o) => o.key),
            blanksSnapshot: q.blanks.map((b) => ({
              acceptableAnswers: b.acceptableAnswers,
              score: b.score,
              ignoreCase: b.ignoreCase,
              trimSpace: b.trimSpace,
            })),
            referenceAnswer: q.referenceAnswer,
            rubric: q.rubric,
            explanation: q.explanation,
            partialRule: q.partialRule,
            needsManualGrading: q.needsManualGrading,
          });
        });
      } else if (mode === "RANDOM" && randomConfig) {
        totalScore = Number(randomConfig.count || 0) * Number(randomConfig.scorePerQuestion || 10);
      }

      return tx.exam.create({
        data: {
          teacherId: session.userId,
          bankId: bankId || null,
          title: String(title).trim(),
          description: description || null,
          mode: mode || "MANUAL",
          status: "DRAFT",
          startTime: startTime ? new Date(startTime) : new Date(),
          endTime: endTime ? new Date(endTime) : new Date(Date.now() + 7 * 86400000),
          durationMinutes: Number(durationMinutes) || 60,
          totalScore,
          allowEarlySubmit: allowEarlySubmit !== false,
          allowRetake: Boolean(allowRetake),
          releasePolicy: releasePolicy || "IMMEDIATE",
          showAnswers: showAnswers !== false,
          randomConfig: randomConfig || undefined,
          assignments: Array.isArray(classIds) ? { create: classIds.map((cid: string) => ({ classId: cid })) } : undefined,
          questions: snapshotCreates.length ? { create: snapshotCreates as never } : undefined,
        },
      });
    });

    await logAudit({ userId: session.userId, actorName: session.name, action: "CREATE_EXAM", target: exam.id, detail: `创建考试《${exam.title}》` });
    return NextResponse.json({ exam });
  } catch (e) {
    return NextResponse.json({ error: "创建考试失败", detail: String(e) }, { status: 500 });
  }
}
