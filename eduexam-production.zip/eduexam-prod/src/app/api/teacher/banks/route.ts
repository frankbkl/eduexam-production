import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { logAudit } from "@/lib/audit";

export async function GET() {
  try {
    const session = await requireRole(["TEACHER"]);
    const banks = await prisma.questionBank.findMany({
      where: { teacherId: session.userId },
      include: { _count: { select: { questions: true } } },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ banks });
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : "";
    return NextResponse.json({ error: msg }, { status: msg === "UNAUTHORIZED" ? 401 : 403 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await requireRole(["TEACHER"]);
    const { name, subject, description } = await req.json();
    if (!name) return NextResponse.json({ error: "题库名称不能为空" }, { status: 400 });
    const bank = await prisma.questionBank.create({
      data: {
        teacherId: session.userId,
        name: String(name).trim(),
        subject: String(subject || "综合").trim(),
        description: description ? String(description).trim() : null,
      },
    });
    await logAudit({ userId: session.userId, actorName: session.name, action: "CREATE_BANK", target: bank.id, detail: `创建题库《${bank.name}》` });
    return NextResponse.json({ bank });
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : "";
    return NextResponse.json({ error: msg }, { status: msg === "UNAUTHORIZED" ? 401 : 500 });
  }
}
