import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await requireRole(["TEACHER"]);
    const { id } = await params;
    const bank = await prisma.questionBank.findUnique({ where: { id } });
    if (!bank || bank.teacherId !== session.userId) {
      return NextResponse.json({ error: "无权操作该题库" }, { status: 403 });
    }
    await prisma.questionBank.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "删除失败" }, { status: 500 });
  }
}
