import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import crypto from "crypto";

function contentHash(type: string, content: string) {
  return crypto.createHash("sha256").update(`${type}::${content.trim().toLowerCase()}`).digest("hex");
}

export async function GET(req: NextRequest) {
  try {
    const session = await requireRole(["TEACHER"]);
    const bankId = req.nextUrl.searchParams.get("bankId");
    if (!bankId) return NextResponse.json({ error: "缺少 bankId" }, { status: 400 });
    const bank = await prisma.questionBank.findUnique({ where: { id: bankId } });
    if (!bank || bank.teacherId !== session.userId) return NextResponse.json({ error: "无权访问题库" }, { status: 403 });

    const questions = await prisma.question.findMany({
      where: { bankId },
      include: { options: true, blanks: true },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ questions });
  } catch {
    return NextResponse.json({ error: "查询失败" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await requireRole(["TEACHER"]);
    const body = await req.json();
    const bank = await prisma.questionBank.findUnique({ where: { id: body.bankId } });
    if (!bank || bank.teacherId !== session.userId) return NextResponse.json({ error: "无权操作题库" }, { status: 403 });

    const q = await prisma.question.create({
      data: {
        bankId: body.bankId,
        type: body.type,
        content: String(body.content).trim(),
        contentHash: contentHash(body.type, String(body.content)),
        difficulty: body.difficulty || "中等",
        topic: body.topic || "综合",
        score: Number(body.score) || 10,
        explanation: body.explanation || null,
        referenceAnswer: body.referenceAnswer || null,
        rubric: body.rubric || null,
        needsManualGrading: body.type === "SUBJECTIVE",
        partialRule: body.type === "MULTIPLE" ? "ALL_OR_HALF" : null,
        options: body.options ? { create: body.options } : undefined,
        blanks: body.blanks ? { create: body.blanks } : undefined,
      },
      include: { options: true, blanks: true },
    });
    return NextResponse.json({ question: q });
  } catch (e) {
    return NextResponse.json({ error: "创建试题失败", detail: String(e) }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const session = await requireRole(["TEACHER"]);
    const id = req.nextUrl.searchParams.get("id");
    if (!id) return NextResponse.json({ error: "缺少 id" }, { status: 400 });
    const q = await prisma.question.findUnique({ where: { id }, include: { bank: true } });
    if (!q || q.bank.teacherId !== session.userId) return NextResponse.json({ error: "无权删除" }, { status: 403 });
    await prisma.question.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "删除失败" }, { status: 500 });
  }
}
