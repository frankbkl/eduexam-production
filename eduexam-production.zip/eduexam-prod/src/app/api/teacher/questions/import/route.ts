import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import * as XLSX from "xlsx";
import crypto from "crypto";
import { QuestionType } from "@prisma/client";

function hashQ(type: string, content: string) {
  return crypto.createHash("sha256").update(`${type}::${content.trim().toLowerCase()}`).digest("hex");
}

export async function POST(req: NextRequest) {
  try {
    const session = await requireRole(["TEACHER"]);
    const formData = await req.formData();
    const bankId = String(formData.get("bankId") || "");
    const confirm = formData.get("confirm") === "true";
    const file = formData.get("file") as File | null;

    if (!bankId || !file) return NextResponse.json({ error: "缺少题库或文件" }, { status: 400 });
    const bank = await prisma.questionBank.findUnique({ where: { id: bankId } });
    if (!bank || bank.teacherId !== session.userId) return NextResponse.json({ error: "无权操作该题库" }, { status: 403 });

    const buffer = Buffer.from(await file.arrayBuffer());
    const wb = XLSX.read(buffer, { type: "buffer" });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const rawRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: "" });

    const existing = await prisma.question.findMany({ where: { bankId }, select: { contentHash: true } });
    const seen = new Set(existing.map((e) => e.contentHash));

    const typeMap: Record<string, QuestionType> = {
      "单选": "SINGLE", "单选题": "SINGLE",
      "多选": "MULTIPLE", "多选题": "MULTIPLE",
      "填空": "BLANK", "填空题": "BLANK",
      "解答": "SUBJECTIVE", "解答题": "SUBJECTIVE",
    };

    const preview: Array<{ rowNum: number; ok: boolean; typeStr: string; content: string; error?: string }> = [];
    const validItems: Array<{
      type: QuestionType; content: string; hash: string; options?: Array<{ key: string; text: string; isCorrect: boolean }>;
      blanks?: Array<{ blankIndex: number; acceptableAnswers: string[]; score: number; ignoreCase: boolean; trimSpace: boolean }>;
      referenceAnswer?: string; explanation?: string; score: number; topic: string; difficulty: string;
    }> = [];

    rawRows.forEach((row, idx) => {
      const rowNum = idx + 2;
      const typeStr = String(row["题型"] || "").trim();
      const content = String(row["题目内容"] || "").trim();
      const optStr = String(row["选项"] || "").trim();
      const ansStr = String(row["正确答案"] || "").trim();
      const refStr = String(row["参考答案"] || "").trim();
      const expStr = String(row["解析"] || "").trim();
      const score = Number(row["分值"] || 0);
      const topic = String(row["知识点"] || "综合").trim();
      const difficulty = String(row["难度"] || "中等").trim();

      const type = typeMap[typeStr];
      let error = "";
      if (!type) error = `未知题型 "${typeStr}"`;
      else if (!content) error = "题目内容不能为空";
      else if (!score || score <= 0) error = "分值必须大于 0";

      const h = type ? hashQ(type, content) : "";
      if (!error && seen.has(h)) error = "题库内已存在重复题目";
      if (!error && (type === "SINGLE" || type === "MULTIPLE") && (!optStr || !ansStr)) {
        error = "选择题缺少选项或正确答案";
      }

      if (error) {
        preview.push({ rowNum, ok: false, typeStr, content, error });
        return;
      }

      seen.add(h);
      const ansSet = new Set(ansStr.toUpperCase().split(/[|,;\s]+/).filter(Boolean));
      const item: (typeof validItems)[number] = {
        type, content, hash: h, score, topic, difficulty, explanation: expStr, referenceAnswer: refStr,
      };

      if (type === "SINGLE" || type === "MULTIPLE") {
        item.options = optStr.split("|").map((s, i) => {
          const m = s.trim().match(/^([A-Z])[\.、\s]*(.+)$/i);
          const key = m ? m[1].toUpperCase() : String.fromCharCode(65 + i);
          const text = m ? m[2].trim() : s.trim();
          return { key, text, isCorrect: ansSet.has(key) };
        });
      } else if (type === "BLANK") {
        item.blanks = [{
          blankIndex: 0,
          acceptableAnswers: ansStr.split("|").map((s) => s.trim()).filter(Boolean),
          score,
          ignoreCase: true,
          trimSpace: true,
        }];
      }

      preview.push({ rowNum, ok: true, typeStr, content });
      validItems.push(item);
    });

    if (!confirm) {
      return NextResponse.json({
        preview,
        validCount: validItems.length,
        invalidCount: preview.length - validItems.length,
      });
    }

    await prisma.$transaction(async (tx) => {
      for (const item of validItems) {
        await tx.question.create({
          data: {
            bankId,
            type: item.type,
            content: item.content,
            contentHash: item.hash,
            score: item.score,
            topic: item.topic,
            difficulty: item.difficulty,
            explanation: item.explanation || null,
            referenceAnswer: item.referenceAnswer || null,
            needsManualGrading: item.type === "SUBJECTIVE",
            partialRule: item.type === "MULTIPLE" ? "ALL_OR_HALF" : null,
            options: item.options ? { create: item.options } : undefined,
            blanks: item.blanks ? { create: item.blanks } : undefined,
          },
        });
      }
    });

    await logAudit({
      userId: session.userId,
      actorName: session.name,
      action: "BULK_IMPORT",
      target: bankId,
      detail: `批量导入 ${validItems.length} 道试题，拦截 ${preview.length - validItems.length} 条异常`,
    });

    return NextResponse.json({
      importedCount: validItems.length,
      failedCount: preview.length - validItems.length,
      preview,
    });
  } catch (e) {
    return NextResponse.json({ error: "导入解析失败", detail: String(e) }, { status: 500 });
  }
}
