import { NextResponse } from "next/server";
import * as XLSX from "xlsx";

export async function GET() {
  const rows = [
    ["题型", "题目内容", "选项", "正确答案", "参考答案", "解析", "分值", "知识点", "难度"],
    ["单选", "HTTP 状态码 404 表示什么？", "A.服务器错误|B.未找到资源|C.成功|D.未授权", "B", "", "404 表示请求资源不存在", 5, "计算机网络", "简单"],
    ["多选", "以下属于稳定排序算法的是？", "A.冒泡排序|B.归并排序|C.快速排序|D.插入排序", "A|B|D", "", "快排是不稳定排序", 10, "排序算法", "中等"],
    ["填空", "TCP 三次握手中第一次发送的标志位是 ____ 。", "", "SYN", "", "客户端首先发送 SYN 报文", 5, "计算机网络", "简单"],
    ["解答", "简述进程与线程的区别。", "", "", "进程是资源分配基本单位，线程是调度基本单位。", "答出资源分配与调度区别各得一半分数", 20, "操作系统", "中等"],
  ];
  const ws = XLSX.utils.aoa_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "题库导入模板");
  const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });

  return new NextResponse(buf, {
    headers: {
      "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Content-Disposition": "attachment; filename=eduexam_question_template.xlsx",
    },
  });
}
