import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { hashPassword, createSessionToken, setSessionCookie } from "@/lib/auth";
import { logAudit } from "@/lib/audit";

export async function POST(req: NextRequest) {
  try {
    const { name, email, password } = await req.json();
    if (!name || !email || !password || String(password).length < 6) {
      return NextResponse.json({ error: "请填写完整信息且密码不少于 6 位" }, { status: 400 });
    }
    const cleanEmail = String(email).trim().toLowerCase();
    const exists = await prisma.user.findUnique({ where: { email: cleanEmail } });
    if (exists) {
      return NextResponse.json({ error: "该邮箱已被注册" }, { status: 409 });
    }
    const passwordHash = await hashPassword(String(password));
    const user = await prisma.user.create({
      data: {
        name: String(name).trim(),
        email: cleanEmail,
        passwordHash,
        role: "TEACHER",
        teacherProfile: { create: { title: "教师" } },
      },
    });
    const token = await createSessionToken({ userId: user.id, email: user.email, name: user.name, role: user.role });
    await setSessionCookie(token);
    await logAudit({ userId: user.id, actorName: user.name, action: "REGISTER_TEACHER", detail: `教师 ${user.name} 注册` });
    return NextResponse.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (e) {
    return NextResponse.json({ error: "注册失败", detail: String(e) }, { status: 500 });
  }
}
