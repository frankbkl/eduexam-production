import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { ShellNav } from "@/components/ShellNav";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") redirect("/login");

  return (
    <div className="flex min-h-screen">
      <ShellNav
        roleTitle="系统管理后台"
        userName={session.name}
        items={[{ href: "/admin", label: "账号、班级与审计" }]}
      />
      <main className="flex-1 p-6 max-w-6xl mx-auto">{children}</main>
    </div>
  );
}
