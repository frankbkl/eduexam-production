"use client";

import { useEffect, useState } from "react";

export default function AdminPage() {
  const [users, setUsers] = useState<Array<{ id: string; name: string; email: string; role: string; status: string }>>([]);
  const [classes, setClasses] = useState<Array<{ id: string; name: string; grade: string }>>([]);
  const [logs, setLogs] = useState<Array<{ id: string; actorName: string; action: string; detail: string; createdAt: string }>>([]);
  const [newName, setNewName] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [newRole, setNewRole] = useState("STUDENT");

  async function loadAll() {
    const [uRes, cRes, lRes] = await Promise.all([
      fetch("/api/admin/users").then((r) => r.json()),
      fetch("/api/admin/classes").then((r) => r.json()),
      fetch("/api/admin/audit-logs").then((r) => r.json()),
    ]);
    setUsers(uRes.users || []);
    setClasses(cRes.classes || []);
    setLogs(lRes.logs || []);
  }

  useEffect(() => { loadAll(); }, []);

  async function createUser(e: React.FormEvent) {
    e.preventDefault();
    await fetch("/api/admin/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: newName, email: newEmail, role: newRole }),
    });
    setNewName(""); setNewEmail("");
    loadAll();
  }

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-900">系统管理后台</h1>

      <form onSubmit={createUser} className="bg-white border border-slate-200 rounded-xl p-4 flex flex-wrap gap-3 items-end">
        <div>
          <label className="block text-xs text-slate-600 mb-1">姓名</label>
          <input value={newName} onChange={(e) => setNewName(e.target.value)} required className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm" />
        </div>
        <div>
          <label className="block text-xs text-slate-600 mb-1">邮箱</label>
          <input type="email" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} required className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm" />
        </div>
        <div>
          <label className="block text-xs text-slate-600 mb-1">角色</label>
          <select value={newRole} onChange={(e) => setNewRole(e.target.value)} className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm">
            <option value="STUDENT">学生</option>
            <option value="TEACHER">教师</option>
          </select>
        </div>
        <button type="submit" className="px-4 py-1.5 bg-blue-700 text-white rounded-lg text-sm font-medium">创建账号 (默认密码 123456)</button>
      </form>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <h2 className="font-semibold mb-3">用户列表 ({users.length})</h2>
          <div className="space-y-2 text-sm">
            {users.map((u) => (
              <div key={u.id} className="flex justify-between border-b border-slate-100 pb-2">
                <span><strong>{u.name}</strong> ({u.role})</span>
                <span className="text-slate-500 font-mono text-xs">{u.email}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <h2 className="font-semibold mb-3">班级列表 ({classes.length})</h2>
          <div className="space-y-2 text-sm">
            {classes.map((c) => (
              <div key={c.id} className="flex justify-between border-b border-slate-100 pb-2">
                <span><strong>{c.name}</strong></span>
                <span className="text-slate-500">{c.grade}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-5">
        <h2 className="font-semibold mb-3">关键操作审计日志</h2>
        <div className="space-y-2 text-xs">
          {logs.slice(0, 15).map((l) => (
            <div key={l.id} className="flex justify-between border-b border-slate-100 pb-1.5">
              <span><strong>{l.actorName}</strong> [{l.action}] {l.detail}</span>
              <span className="text-slate-400 font-mono">{new Date(l.createdAt).toLocaleString()}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
