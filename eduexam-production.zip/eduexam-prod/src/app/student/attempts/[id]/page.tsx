"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";

export default function StudentAttemptResultPage() {
  const { id } = useParams<{ id: string }>();
  const [data, setData] = useState<{ attempt: Record<string, unknown>; questions: Array<Record<string, unknown>> } | null>(null);

  useEffect(() => {
    fetch(`/api/student/attempts/${id}`).then((r) => r.json()).then(setData);
  }, [id]);

  if (!data?.attempt) return <div className="text-sm text-slate-500">加载中...</div>;

  const att = data.attempt;
  const confirmed = att.teacherConfirmed === true && att.status === "GRADED";
  const answers = (att.answers as Array<{ examQuestionId: string; answerPayload: unknown }>) || [];

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-5 flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-slate-900">{String(att.examTitle)} — 交卷结果</h1>
          <p className="text-sm text-slate-500">
            状态：{confirmed ? `已出分 (${String(att.totalScore)} / ${String(att.examTotalScore)})` : "待教师阅卷确认"}
          </p>
        </div>
        <Link href="/student" className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm">返回列表</Link>
      </div>

      {!confirmed && (
        <div className="bg-amber-50 border border-amber-200 text-amber-800 rounded-xl p-4 text-sm">
          教师尚未完成阅卷或确认公布，当前仅展示您的作答内容；标准答案与解析将在教师批改确认后开放。
        </div>
      )}

      {data.questions.map((q, idx) => {
        const qid = String(q.id);
        const ans = answers.find((a) => a.examQuestionId === qid)?.answerPayload;
        return (
          <div key={qid} className="bg-white border border-slate-200 rounded-xl p-4 space-y-2">
            <div className="font-medium text-sm">第 {idx + 1} 题 ({String(q.type)}) · 满分 {String(q.score)} 分</div>
            <p className="text-slate-800">{String(q.content)}</p>
            <p className="text-sm text-blue-700">我的作答：{JSON.stringify(ans ?? "未作答")}</p>
            {confirmed && q.explanation !== undefined && (
              <div className="text-sm text-emerald-700 space-y-1 pt-1 border-t border-slate-100">
                <div>标准/参考答案：{JSON.stringify(q.correctAnswer ?? q.referenceAnswer ?? "-")}</div>
                <div className="text-slate-600">解析：{String(q.explanation || "暂无")}</div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
