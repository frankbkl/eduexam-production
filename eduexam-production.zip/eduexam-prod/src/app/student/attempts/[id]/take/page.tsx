"use client";

import { useEffect, useState, useRef } from "react";
import { useParams, useRouter } from "next/navigation";

interface QuestionItem {
  id: string;
  type: string;
  content: string;
  score: number;
  optionsSnapshot?: Array<{ key: string; text: string }>;
  blankCount?: number;
}

export default function ExamTakePage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [questions, setQuestions] = useState<QuestionItem[]>([]);
  const [answers, setAnswers] = useState<Record<string, unknown>>({});
  const [expiresAt, setExpiresAt] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState("--:--");
  const [saveState, setSaveState] = useState("已就绪");
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    fetch(`/api/student/attempts/${id}`)
      .then((r) => r.json())
      .then((data) => {
        if (!data.attempt || data.attempt.status !== "IN_PROGRESS") {
          router.replace(`/student/attempts/${id}`);
          return;
        }
        setTitle(data.attempt.examTitle);
        setQuestions(data.questions || []);
        setExpiresAt(new Date(data.attempt.expiresAt).getTime());
        const map: Record<string, unknown> = {};
        (data.attempt.answers || []).forEach((a: { examQuestionId: string; answerPayload: unknown }) => {
          map[a.examQuestionId] = a.answerPayload;
        });
        setAnswers(map);
      });
  }, [id, router]);

  useEffect(() => {
    if (!expiresAt) return;
    timerRef.current = setInterval(() => {
      const diff = expiresAt - Date.now();
      if (diff <= 0) {
        if (timerRef.current) clearInterval(timerRef.current);
        submitExam();
        return;
      }
      const sec = Math.floor(diff / 1000);
      setTimeLeft(`${String(Math.floor(sec / 60)).padStart(2, "0")}:${String(sec % 60).padStart(2, "0")}`);
    }, 1000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [expiresAt]);

  async function syncAnswer(qid: string, payload: unknown) {
    setAnswers((prev) => ({ ...prev, [qid]: payload }));
    setSaveState("正在保存...");
    await fetch(`/api/student/attempts/${id}/answers`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ answers: [{ examQuestionId: qid, answerPayload: payload }] }),
    });
    setSaveState(`已自动保存 ${new Date().toLocaleTimeString()}`);
  }

  async function submitExam() {
    await fetch(`/api/student/attempts/${id}/submit`, { method: "POST" });
    router.replace(`/student/attempts/${id}`);
  }

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between sticky top-4 shadow-sm">
        <div>
          <h1 className="font-bold text-slate-900">{title}</h1>
          <div className="text-xs text-slate-500">{saveState}</div>
        </div>
        <div className="flex items-center gap-4">
          <span className="font-mono font-bold text-blue-700 bg-blue-50 px-3 py-1.5 rounded-lg border border-blue-200">{timeLeft}</span>
          <button onClick={submitExam} className="px-4 py-2 bg-blue-700 text-white rounded-lg text-sm font-medium">交卷</button>
        </div>
      </div>

      {questions.map((q, idx) => (
        <div key={q.id} className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
          <div className="text-sm font-semibold">第 {idx + 1} 题 ({q.type}) · {q.score} 分</div>
          <p className="text-slate-800">{q.content}</p>

          {q.type === "SINGLE" && q.optionsSnapshot?.map((o) => (
            <label key={o.key} className="flex items-center gap-2 p-2.5 border border-slate-200 rounded-lg cursor-pointer">
              <input
                type="radio"
                name={q.id}
                checked={Array.isArray(answers[q.id]) && (answers[q.id] as string[])[0] === o.key}
                onChange={() => syncAnswer(q.id, [o.key])}
              />
              <span>{o.key}. {o.text}</span>
            </label>
          ))}

          {q.type === "MULTIPLE" && q.optionsSnapshot?.map((o) => {
            const cur = Array.isArray(answers[q.id]) ? (answers[q.id] as string[]) : [];
            const checked = cur.includes(o.key);
            return (
              <label key={o.key} className="flex items-center gap-2 p-2.5 border border-slate-200 rounded-lg cursor-pointer">
                <input
                  type="checkbox"
                  checked={checked}
                  onChange={() => {
                    const next = checked ? cur.filter((x) => x !== o.key) : [...cur, o.key];
                    syncAnswer(q.id, next);
                  }}
                />
                <span>{o.key}. {o.text}</span>
              </label>
            );
          })}

          {q.type === "BLANK" && Array.from({ length: q.blankCount || 1 }).map((_, bi) => {
            const cur = Array.isArray(answers[q.id]) ? [...(answers[q.id] as string[])] : [];
            return (
              <input
                key={bi}
                value={cur[bi] || ""}
                placeholder={`第 ${bi + 1} 空`}
                onChange={(e) => {
                  cur[bi] = e.target.value;
                  syncAnswer(q.id, cur);
                }}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
              />
            );
          })}

          {q.type === "SUBJECTIVE" && (
            <textarea
              value={typeof answers[q.id] === "string" ? (answers[q.id] as string) : ""}
              onChange={(e) => syncAnswer(q.id, e.target.value)}
              rows={4}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
              placeholder="请输入解答..."
            />
          )}
        </div>
      ))}
    </div>
  );
}
