import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { ShellNav } from "@/components/ShellNav";

export default async function StudentLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();
  if (!session || session.role !== "STUDENT") redirect("/login");

  return (
    <div className="flex min-h-screen">
      <ShellNav
        roleTitle="学生学习端"
        userName={session.name}
        items={[{ href: "/student", label: "我的考试与成绩" }]}
      />
      <main className="flex-1 p-6 max-w-5xl mx-auto">{children}</main>
    </div>
  );
}
