"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

interface ExamItem {
  id: string;
  title: string;
  description: string | null;
  durationMinutes: number;
  totalScore: number;
  allowRetake: boolean;
  attempts: Array<{ id: string; status: string; totalScore: number | null; teacherConfirmed: boolean }>;
}

export default function StudentDashboardPage() {
  const router = useRouter();
  const [exams, setExams] = useState<ExamItem[]>([]);

  useEffect(() => {
    fetch("/api/student/exams").then((r) => r.json()).then((d) => setExams(d.exams || []));
  }, []);

  async function startExam(examId: string) {
    const res = await fetch(`/api/student/exams/${examId}/start`, { method: "POST" });
    const data = await res.json();
    if (data.attempt?.id) {
      router.push(`/student/attempts/${data.attempt.id}/take`);
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-900">我的考试与成绩</h1>
      <div className="bg-white border border-slate-200 rounded-xl p-5">
        <table className="w-full text-sm text-left">
          <thead>
            <tr className="border-b border-slate-200 text-xs text-slate-500">
              <th className="py-2">考试名称</th><th className="py-2">时长</th><th className="py-2">满分</th><th className="py-2">状态</th><th className="py-2">操作</th>
            </tr>
          </thead>
          <tbody>
            {exams.map((e) => {
              const inProg = e.attempts.find((a) => a.status === "IN_PROGRESS");
              const finished = e.attempts.find((a) => a.status !== "IN_PROGRESS");
              return (
                <tr key={e.id} className="border-b border-slate-100">
                  <td className="py-3">
                    <div className="font-medium">{e.title}</div>
                    <div className="text-xs text-slate-500">{e.description}</div>
                  </td>
                  <td className="py-3 font-mono">{e.durationMinutes} 分钟</td>
                  <td className="py-3 font-mono">{e.totalScore}</td>
                  <td className="py-3">{inProg ? "答题中" : finished ? (finished.teacherConfirmed ? `已出分 (${finished.totalScore})` : "待教师确认") : "待参加"}</td>
                  <td className="py-3 space-x-3">
                    {inProg && <Link href={`/student/attempts/${inProg.id}/take`} className="text-blue-700 font-medium">继续答题</Link>}
                    {!inProg && (!finished || e.allowRetake) && (
                      <button onClick={() => startExam(e.id)} className="px-3 py-1 bg-blue-700 text-white rounded text-xs font-medium">开始考试</button>
                    )}
                    {finished && <Link href={`/student/attempts/${finished.id}`} className="text-blue-700 hover:underline">查看结果</Link>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
