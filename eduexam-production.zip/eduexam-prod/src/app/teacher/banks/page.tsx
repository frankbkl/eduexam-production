"use client";

import { useEffect, useState } from "react";

interface Bank { id: string; name: string; subject: string; _count?: { questions: number } }
interface Question { id: string; type: string; content: string; topic: string; difficulty: string; score: number }

export default function TeacherBanksPage() {
  const [banks, setBanks] = useState<Bank[]>([]);
  const [selectedBankId, setSelectedBankId] = useState("");
  const [questions, setQuestions] = useState<Question[]>([]);
  const [bankName, setBankName] = useState("");
  const [bankSubject, setBankSubject] = useState("");
  const [importMsg, setImportMsg] = useState("");

  async function loadBanks() {
    const res = await fetch("/api/teacher/banks");
    const data = await res.json();
    setBanks(data.banks || []);
    if (!selectedBankId && data.banks?.length) setSelectedBankId(data.banks[0].id);
  }

  async function loadQuestions(bid: string) {
    if (!bid) return;
    const res = await fetch(`/api/teacher/questions?bankId=${bid}`);
    const data = await res.json();
    setQuestions(data.questions || []);
  }

  useEffect(() => { loadBanks(); }, []);
  useEffect(() => { if (selectedBankId) loadQuestions(selectedBankId); }, [selectedBankId]);

  async function createBank(e: React.FormEvent) {
    e.preventDefault();
    if (!bankName.trim()) return;
    await fetch("/api/teacher/banks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: bankName, subject: bankSubject || "综合" }),
    });
    setBankName(""); setBankSubject("");
    loadBanks();
  }

  async function handleImport(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !selectedBankId) return;
    const fd = new FormData();
    fd.append("bankId", selectedBankId);
    fd.append("confirm", "true");
    fd.append("file", file);
    const res = await fetch("/api/teacher/questions/import", { method: "POST", body: fd });
    const data = await res.json();
    setImportMsg(`导入完成：成功 ${data.importedCount ?? 0} 条，拦截 ${data.failedCount ?? 0} 条`);
    loadQuestions(selectedBankId);
    loadBanks();
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-xl font-bold text-slate-900">题库与批量导入</h1>
        <a href="/api/teacher/questions/template" className="px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm font-medium hover:bg-slate-50">
          下载 Excel 导入模板 (.xlsx)
        </a>
      </div>

      <form onSubmit={createBank} className="bg-white border border-slate-200 rounded-xl p-4 flex flex-wrap gap-3 items-end">
        <div>
          <label className="block text-xs text-slate-600 mb-1">新题库名称</label>
          <input value={bankName} onChange={(e) => setBankName(e.target.value)} className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm" placeholder="例如：计算机网络" />
        </div>
        <div>
          <label className="block text-xs text-slate-600 mb-1">学科分类</label>
          <input value={bankSubject} onChange={(e) => setBankSubject(e.target.value)} className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm" placeholder="计算机" />
        </div>
        <button type="submit" className="px-4 py-1.5 bg-blue-700 text-white rounded-lg text-sm font-medium">创建题库</button>
      </form>

      <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <select value={selectedBankId} onChange={(e) => setSelectedBankId(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm">
            {banks.map((b) => <option key={b.id} value={b.id}>{b.name} ({b._count?.questions ?? 0} 题)</option>)}
          </select>
          <label className="px-3 py-2 bg-blue-50 text-blue-700 border border-blue-200 rounded-lg text-sm font-medium cursor-pointer">
            上传 Excel 批量导入
            <input type="file" accept=".xlsx,.xls,.csv" onChange={handleImport} className="hidden" />
          </label>
        </div>

        {importMsg && <div className="text-sm text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg p-3">{importMsg}</div>}

        <table className="w-full text-sm text-left">
          <thead>
            <tr className="border-b border-slate-200 text-xs text-slate-500">
              <th className="py-2">题型</th><th className="py-2">题目内容</th><th className="py-2">知识点</th><th className="py-2">难度</th><th className="py-2">分值</th>
            </tr>
          </thead>
          <tbody>
            {questions.map((q) => (
              <tr key={q.id} className="border-b border-slate-100">
                <td className="py-2 font-mono text-xs">{q.type}</td>
                <td className="py-2">{q.content}</td>
                <td className="py-2">{q.topic}</td>
                <td className="py-2">{q.difficulty}</td>
                <td className="py-2 font-mono">{q.score}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
