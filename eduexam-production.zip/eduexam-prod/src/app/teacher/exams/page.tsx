"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

interface Exam { id: string; title: string; status: string; mode: string; durationMinutes: number; totalScore: number }

export default function TeacherExamsPage() {
  const [exams, setExams] = useState<Exam[]>([]);

  async function load() {
    const res = await fetch("/api/teacher/exams");
    const data = await res.json();
    setExams(data.exams || []);
  }

  useEffect(() => { load(); }, []);

  async function publish(id: string) {
    await fetch(`/api/teacher/exams/${id}/publish`, { method: "POST" });
    load();
  }

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-900">考试与成绩管理</h1>
      <div className="bg-white border border-slate-200 rounded-xl p-5">
        <table className="w-full text-sm text-left">
          <thead>
            <tr className="border-b border-slate-200 text-xs text-slate-500">
              <th className="py-2">考试名称</th><th className="py-2">状态</th><th className="py-2">组卷</th><th className="py-2">时长</th><th className="py-2">总分</th><th className="py-2">操作</th>
            </tr>
          </thead>
          <tbody>
            {exams.map((e) => (
              <tr key={e.id} className="border-b border-slate-100">
                <td className="py-2.5 font-medium">{e.title}</td>
                <td className="py-2.5">{e.status}</td>
                <td className="py-2.5">{e.mode}</td>
                <td className="py-2.5 font-mono">{e.durationMinutes} 分钟</td>
                <td className="py-2.5 font-mono">{e.totalScore}</td>
                <td className="py-2.5 space-x-3">
                  {e.status === "DRAFT" && <button onClick={() => publish(e.id)} className="text-blue-700 font-medium">发布</button>}
                  <Link href={`/teacher/exams/${e.id}/results`} className="text-blue-700 hover:underline">成绩分析与阅卷</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
