"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";

interface AttemptRow {
  id: string;
  status: string;
  objectiveScore: number | null;
  totalScore: number | null;
  teacherConfirmed: boolean;
  student: { name: string; studentProfile?: { studentNo: string } | null };
}

export default function ExamResultsPage() {
  const { id } = useParams<{ id: string }>();
  const [examTitle, setExamTitle] = useState("");
  const [attempts, setAttempts] = useState<AttemptRow[]>([]);
  const [activeAttemptId, setActiveAttemptId] = useState<string | null>(null);
  const [detail, setDetail] = useState<{ questions: Array<Record<string, unknown>>; attempt: Record<string, unknown> } | null>(null);
  const [gradeInputs, setGradeInputs] = useState<Record<string, { score: string; comment: string }>>({});

  async function loadResults() {
    const res = await fetch(`/api/teacher/exams/${id}/results`);
    const data = await res.json();
    setExamTitle(data.exam?.title || "");
    setAttempts(data.attempts || []);
  }

  async function openAttempt(attId: string) {
    setActiveAttemptId(attId);
    const res = await fetch(`/api/teacher/attempts/${attId}`);
    const data = await res.json();
    setDetail(data);
    const init: Record<string, { score: string; comment: string }> = {};
    const scores = (data.attempt?.scores as Array<{ examQuestionId: string; score: number | null; comment: string | null }>) || [];
    scores.forEach((s) => {
      init[s.examQuestionId] = { score: s.score !== null ? String(s.score) : "", comment: s.comment || "" };
    });
    setGradeInputs(init);
  }

  async function saveGrading() {
    if (!activeAttemptId) return;
    const grades = Object.entries(gradeInputs)
      .filter(([, v]) => v.score !== "")
      .map(([examQuestionId, v]) => ({ examQuestionId, score: Number(v.score), comment: v.comment }));
    await fetch(`/api/teacher/attempts/${activeAttemptId}/grade`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ grades }),
    });
    setActiveAttemptId(null);
    setDetail(null);
    loadResults();
  }

  useEffect(() => { loadResults(); }, [id]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-xl font-bold text-slate-900">{examTitle} — 成绩与阅卷</h1>
        <a href={`/api/teacher/exams/${id}/export`} className="px-3 py-2 bg-blue-700 text-white rounded-lg text-sm font-medium">
          导出 Excel 成绩单
        </a>
      </div>

      {!activeAttemptId ? (
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <table className="w-full text-sm text-left">
            <thead>
              <tr className="border-b border-slate-200 text-xs text-slate-500">
                <th className="py-2">学生</th><th className="py-2">学号</th><th className="py-2">状态</th><th className="py-2">客观题</th><th className="py-2">总分</th><th className="py-2">操作</th>
              </tr>
            </thead>
            <tbody>
              {attempts.map((a) => (
                <tr key={a.id} className="border-b border-slate-100">
                  <td className="py-2.5 font-medium">{a.student.name}</td>
                  <td className="py-2.5 font-mono">{a.student.studentProfile?.studentNo || "-"}</td>
                  <td className="py-2.5">{a.status}</td>
                  <td className="py-2.5 font-mono">{a.objectiveScore ?? "-"}</td>
                  <td className="py-2.5 font-mono font-bold">{a.totalScore ?? "待阅卷"}</td>
                  <td className="py-2.5">
                    <button onClick={() => openAttempt(a.id)} className="text-blue-700 font-medium">
                      {a.status === "PENDING_GRADING" ? "批改主观题" : "查看/确认"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="space-y-4">
          <button onClick={() => { setActiveAttemptId(null); setDetail(null); }} className="text-sm text-slate-600 hover:underline">← 返回成绩列表</button>
          {detail?.questions.map((q, idx) => {
            const qid = String(q.id);
            const ansList = (detail.attempt?.answers as Array<{ examQuestionId: string; answerPayload: unknown }>) || [];
            const ans = ansList.find((x) => x.examQuestionId === qid)?.answerPayload;
            return (
              <div key={qid} className="bg-white border border-slate-200 rounded-xl p-4 space-y-2">
                <div className="font-medium">第 {idx + 1} 题 ({String(q.type)}) · 满分 {String(q.score)} 分</div>
                <p className="text-sm text-slate-700">{String(q.content)}</p>
                <p className="text-sm text-blue-700">学生作答：{JSON.stringify(ans ?? "未作答")}</p>
                {q.type === "SUBJECTIVE" && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <input
                      type="number"
                      placeholder={`得分 (0-${String(q.score)})`}
                      value={gradeInputs[qid]?.score || ""}
                      onChange={(e) => setGradeInputs({ ...gradeInputs, [qid]: { ...gradeInputs[qid], score: e.target.value } })}
                      className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm"
                    />
                    <input
                      placeholder="评语"
                      value={gradeInputs[qid]?.comment || ""}
                      onChange={(e) => setGradeInputs({ ...gradeInputs, [qid]: { ...gradeInputs[qid], comment: e.target.value } })}
                      className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm"
                    />
                  </div>
                )}
              </div>
            );
          })}
          <button onClick={saveGrading} className="px-4 py-2 bg-blue-700 text-white rounded-lg text-sm font-medium">
            保存评分并确认公布答案与解析
          </button>
        </div>
      )}
    </div>
  );
}
