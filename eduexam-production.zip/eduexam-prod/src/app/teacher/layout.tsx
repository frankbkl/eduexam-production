import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { ShellNav } from "@/components/ShellNav";

export default async function TeacherLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();
  if (!session || session.role !== "TEACHER") redirect("/login");

  return (
    <div className="flex min-h-screen">
      <ShellNav
        roleTitle="教师工作区"
        userName={session.name}
        items={[
          { href: "/teacher", label: "工作台概览" },
          { href: "/teacher/banks", label: "题库与批量导入" },
          { href: "/teacher/exams", label: "考试与成绩管理" },
        ]}
      />
      <main className="flex-1 p-6 max-w-6xl mx-auto">{children}</main>
    </div>
  );
}
