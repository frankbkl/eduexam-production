import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

export default async function TeacherDashboardPage() {
  const session = await getSession();
  if (!session) return null;

  const [banksCount, questionsCount, exams, attemptsCount] = await Promise.all([
    prisma.questionBank.count({ where: { teacherId: session.userId } }),
    prisma.question.count({ where: { bank: { teacherId: session.userId } } }),
    prisma.exam.findMany({ where: { teacherId: session.userId }, orderBy: { createdAt: "desc" }, take: 5 }),
    prisma.examAttempt.count({ where: { exam: { teacherId: session.userId } } }),
  ]);

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-900">教师工作台</h1>
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">题库总数</div>
          <div className="text-2xl font-bold font-mono mt-1">{banksCount}</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">试题总数</div>
          <div className="text-2xl font-bold font-mono mt-1">{questionsCount}</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">已创建考试</div>
          <div className="text-2xl font-bold font-mono mt-1">{exams.length}</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">学生答卷人次</div>
          <div className="text-2xl font-bold font-mono mt-1">{attemptsCount}</div>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-slate-900">最近考试记录</h2>
          <Link href="/teacher/exams" className="text-sm text-blue-700 font-medium">进入考试管理 →</Link>
        </div>
        <table className="w-full text-sm text-left">
          <thead>
            <tr className="border-b border-slate-200 text-slate-500 text-xs">
              <th className="py-2">考试名称</th>
              <th className="py-2">状态</th>
              <th className="py-2">时长</th>
              <th className="py-2">操作</th>
            </tr>
          </thead>
          <tbody>
            {exams.map((e) => (
              <tr key={e.id} className="border-b border-slate-100">
                <td className="py-2.5 font-medium">{e.title}</td>
                <td className="py-2.5">{e.status}</td>
                <td className="py-2.5 font-mono">{e.durationMinutes} 分钟</td>
                <td className="py-2.5">
                  <Link href={`/teacher/exams/${e.id}/results`} className="text-blue-700 hover:underline">成绩与阅卷</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
