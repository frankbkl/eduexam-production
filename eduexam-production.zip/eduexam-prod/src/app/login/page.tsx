"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("teacher@eduexam.cn");
  const [password, setPassword] = useState("Teacher@123");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const endpoint = mode === "login" ? "/api/auth/login" : "/api/auth/register";
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(mode === "login" ? { email, password } : { name, email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "操作失败");
        return;
      }
      const role = data.user?.role;
      router.push(role === "TEACHER" ? "/teacher" : role === "STUDENT" ? "/student" : "/admin");
      router.refresh();
    } catch {
      setError("网络异常，请稍后重试");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50 p-4">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-xl shadow-sm p-7">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-9 h-9 rounded-lg bg-blue-700 text-white font-bold flex items-center justify-center">E</div>
          <div>
            <h1 className="text-lg font-bold text-slate-900">EduExam 在线考试系统</h1>
            <p className="text-xs text-slate-500">教师 · 学生 · 管理员统一认证入口</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 mb-5">
          <button
            type="button"
            onClick={() => setMode("login")}
            className={`py-2 text-sm font-medium rounded-lg border ${mode === "login" ? "bg-blue-700 text-white border-blue-700" : "bg-white text-slate-700 border-slate-200"}`}
          >
            账号登录
          </button>
          <button
            type="button"
            onClick={() => setMode("register")}
            className={`py-2 text-sm font-medium rounded-lg border ${mode === "register" ? "bg-blue-700 text-white border-blue-700" : "bg-white text-slate-700 border-slate-200"}`}
          >
            教师注册
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === "register" && (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">教师姓名</label>
              <input value={name} onChange={(e) => setName(e.target.value)} required className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm" placeholder="陈老师" />
            </div>
          )}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">邮箱</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm" />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">密码</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm" />
          </div>

          {error && <div className="text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded-lg p-2.5">{error}</div>}

          <button disabled={loading} type="submit" className="w-full py-2.5 bg-blue-700 hover:bg-blue-800 text-white rounded-lg text-sm font-medium disabled:opacity-50">
            {loading ? "处理中..." : mode === "login" ? "登录系统" : "注册并登录"}
          </button>
        </form>

        <div className="mt-6 pt-4 border-t border-slate-200 text-xs text-slate-500 space-y-1">
          <div className="font-medium text-slate-700">种子演示账号：</div>
          <div>教师：teacher@eduexam.cn / Teacher@123</div>
          <div>学生：student@eduexam.cn / Student@123</div>
          <div>管理员：admin@eduexam.cn / Admin@123</div>
        </div>
      </div>
    </div>
  );
}
