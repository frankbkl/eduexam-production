import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "EduExam 在线教学题库与考试管理系统",
  description: "企业级在线题库、智能组卷、防作弊考试与阅卷分析平台",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="zh-CN">
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
