import { sweepExpiredAttempts } from "../lib/grading";

async function run() {
  console.log("[EduExam Worker] Auto-submit sweep service started.");
  setInterval(async () => {
    try {
      const count = await sweepExpiredAttempts();
      if (count > 0) {
        console.log(`[EduExam Worker] Auto-submitted ${count} expired attempt(s).`);
      }
    } catch (err) {
      console.error("[EduExam Worker] Sweep error:", err);
    }
  }, 15000);
}

run();
