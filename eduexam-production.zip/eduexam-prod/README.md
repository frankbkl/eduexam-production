# EduExam 在线教学题库与考试管理系统（生产级全栈代码包）

基于 **Next.js 14 (App Router) + TypeScript + Tailwind CSS + Prisma ORM + PostgreSQL 16** 构建，支持教师、学生与管理员三端隔离访问、Excel 批量导入导出、随机/手动不可变题目快照、服务端防作弊倒计时、到期自动交卷 Worker 以及主观题人工阅卷。

## 快速启动（Docker Compose 一键部署）

1. 复制环境变量模板并修改密钥：
   ```bash
   cp .env.example .env
   ```
2. 启动 PostgreSQL、Web 服务与自动交卷 Worker：
   ```bash
   docker compose up -d --build
   ```
3. 初始化演示数据（种子账号与示例考试）：
   ```bash
   docker compose exec web npx tsx prisma/seed.ts
   ```
4. 访问 `http://localhost:3000`。

## 本地开发模式（Node 20 + PostgreSQL 16）

```bash
npm install
npx prisma generate
npx prisma db push
npx tsx prisma/seed.ts
npm run dev
# 另开终端启动到期自动交卷后台 Worker：
npm run worker
```

## 默认测试账号

| 角色 | 邮箱 | 密码 |
|---|---|---|
| 管理员 | `admin@eduexam.cn` | `Admin@123` |
| 教师 | `teacher@eduexam.cn` | `Teacher@123` |
| 学生 1 | `student@eduexam.cn` | `Student@123` |
| 学生 2 | `wang@eduexam.cn` | `Student@123` |
