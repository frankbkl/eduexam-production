import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import crypto from "crypto";

const prisma = new PrismaClient();

function hashContent(type: string, content: string) {
  return crypto.createHash("sha256").update(`${type}::${content.trim().toLowerCase()}`).digest("hex");
}

async function main() {
  const adminPass = await bcrypt.hash("Admin@123", 10);
  const teacherPass = await bcrypt.hash("Teacher@123", 10);
  const studentPass = await bcrypt.hash("Student@123", 10);

  const admin = await prisma.user.upsert({
    where: { email: "admin@eduexam.cn" },
    update: {},
    create: { name: "系统管理员", email: "admin@eduexam.cn", passwordHash: adminPass, role: "ADMIN" },
  });

  const teacher = await prisma.user.upsert({
    where: { email: "teacher@eduexam.cn" },
    update: {},
    create: {
      name: "张教授",
      email: "teacher@eduexam.cn",
      passwordHash: teacherPass,
      role: "TEACHER",
      teacherProfile: { create: { employeeNo: "T202001", department: "计算机学院", title: "副教授" } },
    },
    include: { teacherProfile: true },
  });

  const stu1 = await prisma.user.upsert({
    where: { email: "student@eduexam.cn" },
    update: {},
    create: {
      name: "李明",
      email: "student@eduexam.cn",
      passwordHash: studentPass,
      role: "STUDENT",
      studentProfile: { create: { studentNo: "20230101", major: "计算机科学与技术" } },
    },
    include: { studentProfile: true },
  });

  const stu2 = await prisma.user.upsert({
    where: { email: "wang@eduexam.cn" },
    update: {},
    create: {
      name: "王芳",
      email: "wang@eduexam.cn",
      passwordHash: studentPass,
      role: "STUDENT",
      studentProfile: { create: { studentNo: "20230102", major: "计算机科学与技术" } },
    },
    include: { studentProfile: true },
  });

  const cls = await prisma.class.create({
    data: { name: "计科 2301 班", grade: "2023级" },
  });

  if (teacher.teacherProfile) {
    await prisma.teacherClass.create({ data: { classId: cls.id, teacherId: teacher.teacherProfile.id } });
  }
  if (stu1.studentProfile && stu2.studentProfile) {
    await prisma.classStudent.createMany({
      data: [
        { classId: cls.id, studentId: stu1.studentProfile.id },
        { classId: cls.id, studentId: stu2.studentProfile.id },
      ],
    });
  }

  const bank = await prisma.questionBank.create({
    data: {
      teacherId: teacher.id,
      name: "数据结构与算法核心题库",
      subject: "计算机科学",
      description: "线性表、栈队列、二叉树与排序算法",
    },
  });

  const q1 = await prisma.question.create({
    data: {
      bankId: bank.id,
      type: "SINGLE",
      content: "在长度为 n 的顺序表中删除第 i 个元素（1 ≤ i ≤ n），需要向前移动多少个元素？",
      contentHash: hashContent("SINGLE", "在长度为 n 的顺序表中删除第 i 个元素（1 ≤ i ≤ n），需要向前移动多少个元素？"),
      difficulty: "简单",
      topic: "线性表",
      score: 10,
      explanation: "第 i+1 到第 n 个元素依次前移一位，共 n - i 个元素。",
      options: {
        create: [
          { key: "A", text: "n - i", isCorrect: true },
          { key: "B", text: "n - i + 1", isCorrect: false },
          { key: "C", text: "n - i - 1", isCorrect: false },
          { key: "D", text: "i", isCorrect: false },
        ],
      },
    },
  });

  const q2 = await prisma.question.create({
    data: {
      bankId: bank.id,
      type: "MULTIPLE",
      content: "以下关于栈和队列的描述中，正确的有哪些？",
      contentHash: hashContent("MULTIPLE", "以下关于栈和队列的描述中，正确的有哪些？"),
      difficulty: "中等",
      topic: "栈与队列",
      score: 15,
      partialRule: "ALL_OR_HALF",
      explanation: "队列遵循先进先出（FIFO），因此 C 错误。",
      options: {
        create: [
          { key: "A", text: "栈遵循后进先出（LIFO）原则", isCorrect: true },
          { key: "B", text: "循环队列可解决顺序队列假溢出问题", isCorrect: true },
          { key: "C", text: "队列遵循先进后出（FILO）原则", isCorrect: false },
          { key: "D", text: "函数调用栈用于保存返回地址与局部变量", isCorrect: true },
        ],
      },
    },
  });

  const q3 = await prisma.question.create({
    data: {
      bankId: bank.id,
      type: "BLANK",
      content: "快速排序的平均时间复杂度为 ____ ，最坏情况退化为 ____ 。",
      contentHash: hashContent("BLANK", "快速排序的平均时间复杂度为 ____ ，最坏情况退化为 ____ 。"),
      difficulty: "简单",
      topic: "排序算法",
      score: 15,
      explanation: "平均复杂度 O(nlogn)，极端退化 O(n^2)。",
      blanks: {
        create: [
          { blankIndex: 0, acceptableAnswers: ["O(nlogn)", "O(n log n)"], score: 8, ignoreCase: true, trimSpace: true },
          { blankIndex: 1, acceptableAnswers: ["O(n^2)", "O(n2)"], score: 7, ignoreCase: true, trimSpace: true },
        ],
      },
    },
  });

  const q4 = await prisma.question.create({
    data: {
      bankId: bank.id,
      type: "SUBJECTIVE",
      content: "简述 BST 与 AVL 树的核心区别，以及 AVL 旋转的意义。",
      contentHash: hashContent("SUBJECTIVE", "简述 BST 与 AVL 树的核心区别，以及 AVL 旋转的意义。"),
      difficulty: "困难",
      topic: "二叉树",
      score: 20,
      referenceAnswer: "BST 可能退化为链表导致 O(n)；AVL 保持左右子树高度差不超过 1，通过旋转维持 O(logn) 查找性能。",
      rubric: "指出 BST 退化（8分）；平衡因子定义（6分）；旋转保持 O(logn)（6分）。",
      needsManualGrading: true,
      explanation: "平衡二叉树通过旋转操作保证最坏情况对数复杂度。",
    },
  });

  const now = new Date();
  const exam = await prisma.exam.create({
    data: {
      teacherId: teacher.id,
      bankId: bank.id,
      title: "2026 秋季《数据结构》阶段性在线测验",
      description: "包含单选、多选、填空及解答题。答题过程自动保存，到期自动交卷。",
      mode: "MANUAL",
      status: "PUBLISHED",
      startTime: new Date(now.getTime() - 3600 * 1000),
      endTime: new Date(now.getTime() + 72 * 3600 * 1000),
      durationMinutes: 45,
      totalScore: 60,
      showAnswers: true,
      assignments: { create: { classId: cls.id } },
      questions: {
        create: [
          {
            originQuestionId: q1.id, orderIndex: 0, type: "SINGLE", content: q1.content, score: 10,
            optionsSnapshot: [{ key: "A", text: "n - i" }, { key: "B", text: "n - i + 1" }, { key: "C", text: "n - i - 1" }, { key: "D", text: "i" }],
            correctAnswer: ["A"], explanation: q1.explanation,
          },
          {
            originQuestionId: q2.id, orderIndex: 1, type: "MULTIPLE", content: q2.content, score: 15,
            optionsSnapshot: [{ key: "A", text: "栈遵循后进先出（LIFO）原则" }, { key: "B", text: "循环队列可解决顺序队列假溢出问题" }, { key: "C", text: "队列遵循先进后出（FILO）原则" }, { key: "D", text: "函数调用栈用于保存返回地址与局部变量" }],
            correctAnswer: ["A", "B", "D"], partialRule: "ALL_OR_HALF", explanation: q2.explanation,
          },
          {
            originQuestionId: q3.id, orderIndex: 2, type: "BLANK", content: q3.content, score: 15,
            blanksSnapshot: [
              { acceptableAnswers: ["O(nlogn)", "O(n log n)"], score: 8, ignoreCase: true, trimSpace: true },
              { acceptableAnswers: ["O(n^2)", "O(n2)"], score: 7, ignoreCase: true, trimSpace: true },
            ],
            explanation: q3.explanation,
          },
          {
            originQuestionId: q4.id, orderIndex: 3, type: "SUBJECTIVE", content: q4.content, score: 20,
            referenceAnswer: q4.referenceAnswer, rubric: q4.rubric, needsManualGrading: true, explanation: q4.explanation,
          },
        ],
      },
    },
  });

  await prisma.auditLog.create({
    data: { userId: admin.id, actorName: admin.name, action: "SEED_INIT", detail: `初始化演示数据与考试《${exam.title}》` },
  });

  console.log("Seed completed successfully.");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
